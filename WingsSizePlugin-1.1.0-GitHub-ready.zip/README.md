# WingsSizePlugin 1.1.0

Paper 1.21.11 / Java 21.

Commands:
- /wings on
- /wings off
- /size 0.1-10
- /size 1

Flight:
1. /wings on
2. Jump normally.
3. Press jump a second time while airborne to start flying.
4. Land to stop flying.

The wing model is made from Paper ItemDisplay entities, so no external resource pack is required.
