package me.wingssize;

import org.bukkit.*;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.Display;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerToggleFlightEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Transformation;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.*;

public final class WingsSizePlugin extends JavaPlugin implements Listener {
    private final Set<UUID> enabled = new HashSet<>();
    private final Map<UUID, List<UUID>> models = new HashMap<>();
    private final NamespacedKey modelKey;

    public WingsSizePlugin() {
        modelKey = new NamespacedKey(this, "wing_model");
    }

    @Override
    public void onEnable() {
        getServer().getPluginManager().registerEvents(this, this);

        Objects.requireNonNull(getCommand("wings")).setExecutor((sender, command, label, args) -> {
            if (!(sender instanceof Player p)) return true;
            if (args.length == 1 && args[0].equalsIgnoreCase("on")) {
                enabled.add(p.getUniqueId());
                spawnWings(p);
                p.setAllowFlight(false);
                p.setFlying(false);
                p.sendMessage("§aКрылья включены. Прыгни второй раз в воздухе для полёта.");
            } else if (args.length == 1 && args[0].equalsIgnoreCase("off")) {
                disableWings(p);
            } else {
                p.sendMessage("§e/wings on §7или §e/wings off");
            }
            return true;
        });

        Objects.requireNonNull(getCommand("size")).setExecutor((sender, command, label, args) -> {
            if (!(sender instanceof Player p)) return true;
            double scale = 1.0;
            if (args.length == 1) {
                try {
                    scale = Double.parseDouble(args[0]);
                } catch (NumberFormatException ex) {
                    p.sendMessage("§cУкажи число от 0.1 до 10.");
                    return true;
                }
            }
            scale = Math.max(0.1, Math.min(10.0, scale));
            var attr = p.getAttribute(Attribute.SCALE);
            if (attr != null) attr.setBaseValue(scale);
            p.sendMessage("§aРазмер установлен: §f" + scale);
            return true;
        });

        new BukkitRunnable() {
            @Override public void run() {
                for (Player p : Bukkit.getOnlinePlayers()) {
                    if (!enabled.contains(p.getUniqueId())) continue;

                    if (p.isOnGround()) {
                        p.setAllowFlight(false);
                        p.setFlying(false);
                    } else if (!p.isFlying()) {
                        // Makes the next jump press produce PlayerToggleFlightEvent.
                        p.setAllowFlight(true);
                    }
                    updateWings(p);
                }
            }
        }.runTaskTimer(this, 1L, 1L);
    }

    @EventHandler
    public void onToggleFlight(PlayerToggleFlightEvent event) {
        Player p = event.getPlayer();
        if (!enabled.contains(p.getUniqueId())) return;

        if (!p.isOnGround()) {
            event.setCancelled(true);
            p.setAllowFlight(true);
            p.setFlying(true);
        }
    }

    @EventHandler
    public void onMove(PlayerMoveEvent event) {
        Player p = event.getPlayer();
        if (!enabled.contains(p.getUniqueId())) return;
        if (p.isOnGround() && p.isFlying()) {
            p.setFlying(false);
            p.setAllowFlight(false);
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        disableWings(event.getPlayer());
    }

    private void spawnWings(Player p) {
        removeModel(p);
        List<UUID> ids = new ArrayList<>();
        World world = p.getWorld();

        for (int side : new int[]{-1, 1}) {
            ItemDisplay d = world.spawn(p.getLocation(), ItemDisplay.class);
            ItemStack item = new ItemStack(Material.PURPLE_STAINED_GLASS_PANE);
            ItemMeta meta = item.getItemMeta();
            meta.getPersistentDataContainer().set(modelKey, PersistentDataType.INTEGER, side);
            item.setItemMeta(meta);
            d.setItemStack(item);
            d.setBillboard(Display.Billboard.FIXED);
            ids.add(d.getUniqueId());
        }
        models.put(p.getUniqueId(), ids);
    }

    private void updateWings(Player p) {
        List<UUID> ids = models.get(p.getUniqueId());
        if (ids == null || ids.size() != 2) {
            spawnWings(p);
            return;
        }

        Location base = p.getLocation().clone().add(0, 0.45, 0.25);
        double t = System.currentTimeMillis() / 180.0;
        float flap = (float)Math.sin(t) * 0.25f;

        for (UUID id : ids) {
            var entity = Bukkit.getEntity(id);
            if (!(entity instanceof ItemDisplay d) || !d.isValid()) {
                spawnWings(p);
                return;
            }

            int side = d.getItemStack().getItemMeta()
                    .getPersistentDataContainer()
                    .getOrDefault(modelKey, PersistentDataType.INTEGER, 1);

            Location loc = base.clone().add(side * 0.45, 0, 0);
            d.teleport(loc);

            Quaternionf rot = new Quaternionf()
                    .rotateY((float)Math.toRadians(side * (15 + flap * 35)));

            d.setTransformation(new Transformation(
                    new Vector3f(side * 0.15f, 0, 0.05f),
                    rot,
                    new Vector3f(1.5f, 1.8f, 0.25f),
                    new Quaternionf()
            ));
        }
    }

    private void disableWings(Player p) {
        enabled.remove(p.getUniqueId());
        p.setFlying(false);
        p.setAllowFlight(false);
        removeModel(p);
    }

    private void removeModel(Player p) {
        List<UUID> ids = models.remove(p.getUniqueId());
        if (ids == null) return;
        for (UUID id : ids) {
            var e = Bukkit.getEntity(id);
            if (e != null) e.remove();
        }
    }
}
